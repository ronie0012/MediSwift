import { useState, useEffect } from 'react';

interface DeliveryUpdate {
  orderId: number;
  status: string;
  location: string;
  estimatedTime: string;
}

export function useDeliveryTracking(orderId: number) {
  const [deliveryStatus, setDeliveryStatus] = useState<DeliveryUpdate | null>(null);
  const [isConnected, setIsConnected] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const protocol = window.location.protocol === "https:" ? "wss:" : "ws:";
    const wsUrl = `${protocol}//${window.location.host}/ws`;
    const socket = new WebSocket(wsUrl);

    socket.onopen = () => {
      setIsConnected(true);
      // Start tracking this order
      socket.send(JSON.stringify({
        type: 'track_order',
        orderId
      }));
    };

    socket.onmessage = (event) => {
      try {
        const update = JSON.parse(event.data);
        setDeliveryStatus(update);
      } catch (error) {
        console.error('Failed to parse delivery update:', error);
      }
    };

    socket.onerror = (event) => {
      setError('Failed to connect to tracking server');
      setIsConnected(false);
    };

    socket.onclose = () => {
      setIsConnected(false);
    };

    return () => {
      socket.close();
    };
  }, [orderId]);

  return {
    deliveryStatus,
    isConnected,
    error
  };
}
