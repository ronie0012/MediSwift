import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { type Medicine } from "@shared/schema";
import { useState } from "react";
import { Input } from "@/components/ui/input";
import { Plus, Minus } from "lucide-react";

interface MedicineCardProps {
  medicine: Medicine;
  onAddToCart: (medicine: Medicine, quantity: number) => void;
}

export default function MedicineCard({ medicine, onAddToCart }: MedicineCardProps) {
  const [quantity, setQuantity] = useState(1);

  const incrementQuantity = () => setQuantity(prev => prev + 1);
  const decrementQuantity = () => setQuantity(prev => Math.max(1, prev - 1));

  return (
    <Card className="overflow-hidden">
      <img
        src={medicine.image}
        alt={medicine.name}
        className="h-48 w-full object-cover"
      />
      <CardHeader>
        <CardTitle>{medicine.name}</CardTitle>
      </CardHeader>
      <CardContent>
        <p className="text-sm text-muted-foreground">{medicine.description}</p>
        <p className="mt-2 text-lg font-semibold">₹{medicine.price.toFixed(2)}</p>
      </CardContent>
      <CardFooter className="flex-col gap-4">
        <div className="flex items-center gap-2 w-full">
          <Button
            variant="outline"
            size="icon"
            onClick={decrementQuantity}
            disabled={quantity <= 1}
          >
            <Minus className="h-4 w-4" />
          </Button>
          <Input
            type="number"
            min="1"
            value={quantity}
            onChange={(e) => setQuantity(Math.max(1, parseInt(e.target.value) || 1))}
            className="w-20 text-center"
          />
          <Button
            variant="outline"
            size="icon"
            onClick={incrementQuantity}
          >
            <Plus className="h-4 w-4" />
          </Button>
        </div>
        <Button
          className="w-full"
          variant={medicine.inStock ? "default" : "secondary"}
          disabled={!medicine.inStock}
          onClick={() => onAddToCart(medicine, quantity)}
        >
          {medicine.inStock ? "Add to Cart" : "Out of Stock"}
        </Button>
      </CardFooter>
    </Card>
  );
}