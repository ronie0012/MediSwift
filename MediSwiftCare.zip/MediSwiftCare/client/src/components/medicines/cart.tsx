import { useEffect, useState } from "react";
import { Medicine } from "@shared/schema";
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { ScrollArea } from "@/components/ui/scroll-area";
import { useMutation } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { X, Info } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import DeliveryTracker from "@/components/delivery/delivery-tracker";

interface CartItem {
  medicine: Medicine;
  quantity: number;
}

interface CartProps {
  items: CartItem[];
  onRemoveItem: (id: number) => void;
}

const paymentMethods = [
  { id: "card", label: "Credit/Debit Card" },
  { id: "upi", label: "UPI" },
  { id: "cod", label: "Cash on Delivery" },
];

const DELIVERY_CHARGE = 40;
const FREE_DELIVERY_THRESHOLD = 200;

export default function Cart({ items, onRemoveItem }: CartProps) {
  const { toast } = useToast();
  const [total, setTotal] = useState(0);
  const [discountedTotal, setDiscountedTotal] = useState(0);
  const [address, setAddress] = useState("");
  const [paymentMethod, setPaymentMethod] = useState<string>("cod");
  const [showCheckout, setShowCheckout] = useState(false);
  const [placedOrderId, setPlacedOrderId] = useState<number | null>(null);

  useEffect(() => {
    const subtotal = items.reduce((sum, item) => sum + (item.medicine.price * item.quantity), 0);
    setTotal(subtotal);
    setDiscountedTotal(subtotal * 0.8); // 20% discount
  }, [items]);

  const finalTotal = discountedTotal < FREE_DELIVERY_THRESHOLD
    ? discountedTotal + DELIVERY_CHARGE
    : discountedTotal;

  const remainingForFreeDelivery = Math.max(0, FREE_DELIVERY_THRESHOLD - discountedTotal);

  const createOrderMutation = useMutation({
    mutationFn: async () => {
      if (!address) throw new Error("Please enter your delivery address");

      const res = await apiRequest("POST", "/api/orders", {
        totalAmount: total,
        discountedAmount: discountedTotal,
        deliveryCharge: discountedTotal < FREE_DELIVERY_THRESHOLD ? DELIVERY_CHARGE : 0,
        finalAmount: finalTotal,
        address,
        paymentMethod,
        items: items.map(item => ({
          medicineId: item.medicine.id,
          quantity: item.quantity,
        })),
      });
      return await res.json();
    },
    onSuccess: (order) => {
      toast({
        title: "Order Placed Successfully",
        description: "Your medicines will be delivered in 10 minutes",
      });
      setPlacedOrderId(order.id);
      items.forEach((item) => onRemoveItem(item.medicine.id));
      setShowCheckout(false);
    },
    onError: (error: Error) => {
      toast({
        title: "Failed to Place Order",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  return (
    <Card className="w-80 flex flex-col">
      <CardHeader>
        <CardTitle>Shopping Cart</CardTitle>
      </CardHeader>
      <ScrollArea className="flex-1">
        <CardContent className="space-y-4">
          {items.length === 0 ? (
            <p className="text-sm text-muted-foreground text-center py-4">
              Your cart is empty
            </p>
          ) : (
            items.map((item) => (
              <div
                key={item.medicine.id}
                className="flex items-center justify-between gap-2 border-b pb-2"
              >
                <div>
                  <p className="font-medium">{item.medicine.name}</p>
                  <p className="text-sm text-muted-foreground">
                    ₹{item.medicine.price.toFixed(2)} × {item.quantity}
                  </p>
                </div>
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={() => onRemoveItem(item.medicine.id)}
                >
                  <X className="h-4 w-4" />
                </Button>
              </div>
            ))
          )}
        </CardContent>
      </ScrollArea>
      <CardFooter className="flex flex-col gap-4 border-t pt-4">
        {items.length > 0 && (
          <div className="w-full px-2 py-1 bg-blue-50 rounded-md flex items-start gap-2 text-sm text-blue-600">
            <Info className="h-4 w-4 mt-0.5 flex-shrink-0" />
            {discountedTotal < FREE_DELIVERY_THRESHOLD ? (
              <p>Add items worth ₹{remainingForFreeDelivery.toFixed(2)} more for free delivery!</p>
            ) : (
              <p>Yay! You've got free delivery!</p>
            )}
          </div>
        )}
        <div className="w-full space-y-1">
          <div className="flex justify-between text-sm">
            <span>Subtotal</span>
            <span>₹{total.toFixed(2)}</span>
          </div>
          <div className="flex justify-between text-sm text-green-600 font-medium">
            <span>Discount (20%)</span>
            <span>-₹{(total - discountedTotal).toFixed(2)}</span>
          </div>
          {discountedTotal < FREE_DELIVERY_THRESHOLD && (
            <div className="flex justify-between text-sm text-muted-foreground">
              <span>Delivery Charge</span>
              <span>₹{DELIVERY_CHARGE.toFixed(2)}</span>
            </div>
          )}
          <div className="flex justify-between font-semibold border-t pt-1 mt-1">
            <span>Total</span>
            <span>₹{finalTotal.toFixed(2)}</span>
          </div>
        </div>
        {placedOrderId && (
          <div className="w-full">
            <DeliveryTracker orderId={placedOrderId} />
          </div>
        )}
        <Dialog open={showCheckout} onOpenChange={setShowCheckout}>
          <DialogTrigger asChild>
            <Button
              className="w-full"
              disabled={items.length === 0}
            >
              Proceed to Checkout
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Complete Your Order</DialogTitle>
            </DialogHeader>
            <div className="space-y-6 py-4">
              <div className="space-y-2">
                <Label htmlFor="address">Delivery Address</Label>
                <Input
                  id="address"
                  placeholder="Enter your full address"
                  value={address}
                  onChange={(e) => setAddress(e.target.value)}
                />
              </div>
              <div className="space-y-2">
                <Label>Payment Method</Label>
                <RadioGroup
                  value={paymentMethod}
                  onValueChange={setPaymentMethod}
                  className="space-y-2"
                >
                  {paymentMethods.map((method) => (
                    <div key={method.id} className="flex items-center space-x-2">
                      <RadioGroupItem value={method.id} id={method.id} />
                      <Label htmlFor={method.id}>{method.label}</Label>
                    </div>
                  ))}
                </RadioGroup>
              </div>
              <Button
                className="w-full"
                disabled={!address || createOrderMutation.isPending}
                onClick={() => createOrderMutation.mutate()}
              >
                {createOrderMutation.isPending ? "Processing..." : "Place Order"}
              </Button>
            </div>
          </DialogContent>
        </Dialog>
      </CardFooter>
    </Card>
  );
}