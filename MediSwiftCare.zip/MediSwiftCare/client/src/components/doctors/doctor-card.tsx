import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Calendar } from "@/components/ui/calendar";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { useState } from "react";
import { type Doctor } from "@shared/schema";
import { useMutation } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Star } from "lucide-react";

interface DoctorCardProps {
  doctor: Doctor;
}

export default function DoctorCard({ doctor }: DoctorCardProps) {
  const [selectedDate, setSelectedDate] = useState<Date>();
  const { toast } = useToast();

  const bookAppointmentMutation = useMutation({
    mutationFn: async () => {
      if (!selectedDate) throw new Error("Please select a date");
      
      const res = await apiRequest("POST", "/api/appointments", {
        doctorId: doctor.id,
        appointmentTime: selectedDate.toISOString(),
      });
      return await res.json();
    },
    onSuccess: () => {
      toast({
        title: "Appointment Booked",
        description: `Your appointment with Dr. ${doctor.name} has been scheduled.`,
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Booking Failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  return (
    <Card className="overflow-hidden">
      <img
        src={doctor.image}
        alt={doctor.name}
        className="h-48 w-full object-cover"
      />
      <CardHeader>
        <CardTitle className="flex items-center justify-between">
          <span>Dr. {doctor.name}</span>
          <span className="flex items-center text-sm font-normal text-muted-foreground">
            <Star className="h-4 w-4 fill-yellow-400 text-yellow-400 mr-1" />
            {doctor.rating}
          </span>
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-2">
        <p className="text-sm font-medium">{doctor.specialization}</p>
        <p className="text-sm text-muted-foreground">
          {doctor.availableSlots} slots available today
        </p>
      </CardContent>
      <CardFooter>
        <Dialog>
          <DialogTrigger asChild>
            <Button className="w-full">Book Appointment</Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Book Appointment with Dr. {doctor.name}</DialogTitle>
            </DialogHeader>
            <div className="space-y-4 py-4">
              <Calendar
                mode="single"
                selected={selectedDate}
                onSelect={setSelectedDate}
                className="rounded-md border"
                disabled={{ before: new Date() }}
              />
              <Button
                className="w-full"
                disabled={!selectedDate || bookAppointmentMutation.isPending}
                onClick={() => bookAppointmentMutation.mutate()}
              >
                {bookAppointmentMutation.isPending
                  ? "Booking..."
                  : "Confirm Appointment"}
              </Button>
            </div>
          </DialogContent>
        </Dialog>
      </CardFooter>
    </Card>
  );
}
