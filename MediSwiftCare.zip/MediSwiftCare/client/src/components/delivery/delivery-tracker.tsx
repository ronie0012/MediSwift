import { useDeliveryTracking } from "@/hooks/use-delivery-tracking";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Loader2, MapPin, Clock, Check, Package } from "lucide-react";

interface DeliveryTrackerProps {
  orderId: number;
}

export default function DeliveryTracker({ orderId }: DeliveryTrackerProps) {
  const { deliveryStatus, isConnected, error } = useDeliveryTracking(orderId);

  if (error) {
    return (
      <Card className="bg-red-50">
        <CardContent className="pt-6">
          <p className="text-red-600">{error}</p>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Package className="h-5 w-5" />
          <span>Tracking Order #{orderId}</span>
          {isConnected ? (
            <span className="h-2 w-2 rounded-full bg-green-500" />
          ) : (
            <Loader2 className="h-4 w-4 animate-spin" />
          )}
        </CardTitle>
      </CardHeader>
      <CardContent>
        {deliveryStatus ? (
          <div className="space-y-4">
            <div className="flex items-center gap-2 text-lg font-medium">
              <Check className="h-5 w-5 text-green-500" />
              <span>{deliveryStatus.status}</span>
            </div>
            <div className="space-y-2 rounded-md bg-muted/50 p-3">
              <div className="flex items-center gap-2 text-sm">
                <MapPin className="h-4 w-4 text-blue-500" />
                <span>Current Location: {deliveryStatus.location}</span>
              </div>
              <div className="flex items-center gap-2 text-sm">
                <Clock className="h-4 w-4 text-blue-500" />
                <span>Estimated delivery by: {deliveryStatus.estimatedTime}</span>
              </div>
            </div>
            {deliveryStatus.status === "Out for Delivery" && (
              <p className="text-sm text-muted-foreground">
                Your delivery partner is on the way. Please keep your phone handy.
              </p>
            )}
          </div>
        ) : (
          <div className="flex items-center justify-center py-4">
            <Loader2 className="h-6 w-6 animate-spin text-muted-foreground" />
          </div>
        )}
      </CardContent>
    </Card>
  );
}