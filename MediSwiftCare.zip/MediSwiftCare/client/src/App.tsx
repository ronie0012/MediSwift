import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { AuthProvider } from "@/hooks/use-auth";
import NotFound from "@/pages/not-found";
import AuthPage from "@/pages/auth-page";
import HomePage from "@/pages/home-page";
import MedicinesPage from "@/pages/medicines-page";
import DoctorsPage from "@/pages/doctors-page";
import AmbulancePage from "@/pages/ambulance-page";
import { ProtectedRoute } from "./lib/protected-route";
import Header from "./components/layout/header";
import Sidebar from "./components/layout/sidebar";

function Router() {
  return (
    <div className="flex h-screen">
      <Sidebar />
      <div className="flex-1 flex flex-col overflow-hidden">
        <Header />
        <main className="flex-1 overflow-auto bg-background p-6">
          <Switch>
            <ProtectedRoute path="/" component={HomePage} />
            <ProtectedRoute path="/medicines" component={MedicinesPage} />
            <ProtectedRoute path="/doctors" component={DoctorsPage} />
            <ProtectedRoute path="/ambulance" component={AmbulancePage} />
            <Route path="/auth" component={AuthPage} />
            <Route component={NotFound} />
          </Switch>
        </main>
      </div>
    </div>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <AuthProvider>
        <Router />
        <Toaster />
      </AuthProvider>
    </QueryClientProvider>
  );
}

export default App;
