import { useQuery } from "@tanstack/react-query";
import { type Ambulance } from "@shared/schema";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Loader2, MapPin, Phone } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

export default function AmbulancePage() {
  const { toast } = useToast();

  const { data: ambulances, isLoading } = useQuery<Ambulance[]>({
    queryKey: ["/api/ambulances/available"],
    refetchInterval: 5000, // Poll every 5 seconds for real-time updates
  });

  const handleEmergencyRequest = () => {
    toast({
      title: "Emergency Request Sent",
      description: "An ambulance will be dispatched to your location shortly.",
      duration: 5000,
    });
  };

  return (
    <div className="space-y-6">
      <div className="text-center space-y-4">
        <h1 className="text-4xl font-bold tracking-tight text-red-600">
          Emergency Services
        </h1>
        <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
          Need immediate medical assistance? Our ambulance service is available 24/7.
          Click the button below to request an emergency ambulance.
        </p>
        <Button
          size="lg"
          className="bg-red-600 hover:bg-red-700"
          onClick={handleEmergencyRequest}
        >
          Request Emergency Ambulance
        </Button>
      </div>

      <div className="mt-12">
        <h2 className="text-2xl font-semibold mb-6">Available Ambulances</h2>
        {isLoading ? (
          <div className="flex items-center justify-center h-64">
            <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
          </div>
        ) : (
          <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
            {ambulances?.map((ambulance) => (
              <Card key={ambulance.id}>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <span>Ambulance {ambulance.vehicleNumber}</span>
                    <span
                      className={`h-2 w-2 rounded-full ${
                        ambulance.status === "available"
                          ? "bg-green-500"
                          : "bg-yellow-500"
                      }`}
                    />
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-2">
                  <p className="flex items-center gap-2 text-sm text-muted-foreground">
                    <MapPin className="h-4 w-4" />
                    {ambulance.currentLocation}
                  </p>
                  <p className="flex items-center gap-2 text-sm">
                    <Phone className="h-4 w-4" />
                    Emergency Hotline: <span className="font-semibold">911</span>
                  </p>
                </CardContent>
              </Card>
            ))}
          </div>
        )}
      </div>

      <div className="mt-12">
        <Card>
          <CardHeader>
            <CardTitle>Important Information</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <h3 className="font-semibold mb-2">What to expect:</h3>
              <ul className="list-disc list-inside space-y-1 text-sm text-muted-foreground">
                <li>Average response time: 8-10 minutes</li>
                <li>Trained medical professionals onboard</li>
                <li>Real-time location tracking</li>
                <li>Direct communication with emergency team</li>
              </ul>
            </div>
            <div>
              <h3 className="font-semibold mb-2">Before the ambulance arrives:</h3>
              <ul className="list-disc list-inside space-y-1 text-sm text-muted-foreground">
                <li>Stay calm and provide clear location details</li>
                <li>Keep your phone line open</li>
                <li>Clear the access path for the ambulance</li>
                <li>Have identification documents ready</li>
              </ul>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
