import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { useAuth } from "@/hooks/use-auth";
import { Pill, User, Ambulance, Clock } from "lucide-react";
import { Link } from "wouter";

export default function HomePage() {
  const { user } = useAuth();

  return (
    <div className="space-y-8">
      <section className="space-y-4">
        <h1 className="text-4xl font-bold tracking-tight text-blue-900">
          Welcome back, {user?.fullName.split(' ')[0]}
        </h1>
        <p className="text-lg text-muted-foreground">
          Your one-stop healthcare platform for all medical needs
        </p>
      </section>

      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-4">
        <Link href="/medicines">
          <Card className="hover:shadow-lg transition-shadow cursor-pointer">
            <CardHeader className="space-y-1">
              <div className="bg-blue-100 w-10 h-10 rounded-full flex items-center justify-center">
                <Pill className="h-6 w-6 text-blue-600" />
              </div>
              <CardTitle>Medicines</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-muted-foreground">
                Order medicines with 10-minute delivery guarantee
              </p>
            </CardContent>
          </Card>
        </Link>

        <Link href="/doctors">
          <Card className="hover:shadow-lg transition-shadow cursor-pointer">
            <CardHeader className="space-y-1">
              <div className="bg-green-100 w-10 h-10 rounded-full flex items-center justify-center">
                <User className="h-6 w-6 text-green-600" />
              </div>
              <CardTitle>Doctors</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-muted-foreground">
                Book instant appointments with top specialists
              </p>
            </CardContent>
          </Card>
        </Link>

        <Link href="/ambulance">
          <Card className="hover:shadow-lg transition-shadow cursor-pointer">
            <CardHeader className="space-y-1">
              <div className="bg-red-100 w-10 h-10 rounded-full flex items-center justify-center">
                <Ambulance className="h-6 w-6 text-red-600" />
              </div>
              <CardTitle>Ambulance</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-muted-foreground">
                Emergency services with real-time tracking
              </p>
            </CardContent>
          </Card>
        </Link>

        <Card className="bg-gradient-to-br from-blue-500 to-blue-600 text-white">
          <CardHeader className="space-y-1">
            <div className="bg-white/20 w-10 h-10 rounded-full flex items-center justify-center">
              <Clock className="h-6 w-6 text-white" />
            </div>
            <CardTitle>Special Offer</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-sm text-blue-50">
              Get 20% off on all orders today!
            </p>
          </CardContent>
        </Card>
      </div>

      <section className="space-y-4">
        <h2 className="text-2xl font-semibold tracking-tight">
          Latest Updates
        </h2>
        <div className="grid gap-4 md:grid-cols-2">
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Health Tips</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-muted-foreground">
                Stay hydrated and maintain good hygiene for better health.
              </p>
            </CardContent>
          </Card>
        </div>
      </section>
    </div>
  );
}