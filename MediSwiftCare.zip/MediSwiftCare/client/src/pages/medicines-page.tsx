import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { type Medicine } from "@shared/schema";
import { Input } from "@/components/ui/input";
import { Loader2, Search } from "lucide-react";
import MedicineCard from "@/components/medicines/medicine-card";
import Cart from "@/components/medicines/cart";

interface CartItem {
  medicine: Medicine;
  quantity: number;
}

export default function MedicinesPage() {
  const [cartItems, setCartItems] = useState<CartItem[]>([]);
  const [searchQuery, setSearchQuery] = useState("");

  const { data: medicines, isLoading } = useQuery<Medicine[]>({
    queryKey: ["/api/medicines"],
  });

  const filteredMedicines = medicines?.filter((medicine) =>
    medicine.name.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const handleAddToCart = (medicine: Medicine, quantity: number) => {
    setCartItems((prev) => {
      const existingItem = prev.find(item => item.medicine.id === medicine.id);
      if (existingItem) {
        return prev.map(item =>
          item.medicine.id === medicine.id
            ? { ...item, quantity: item.quantity + quantity }
            : item
        );
      }
      return [...prev, { medicine, quantity }];
    });
  };

  const handleRemoveFromCart = (medicineId: number) => {
    setCartItems((prev) => prev.filter(item => item.medicine.id !== medicineId));
  };

  return (
    <div className="flex gap-6">
      <div className="flex-1 space-y-6">
        <div className="flex items-center justify-between">
          <h1 className="text-3xl font-bold tracking-tight">Medicines</h1>
          <div className="relative w-72">
            <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
            <Input
              placeholder="Search medicines..."
              className="pl-9"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
          </div>
        </div>

        {isLoading ? (
          <div className="flex items-center justify-center h-64">
            <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
          </div>
        ) : (
          <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
            {filteredMedicines?.map((medicine) => (
              <MedicineCard
                key={medicine.id}
                medicine={medicine}
                onAddToCart={handleAddToCart}
              />
            ))}
          </div>
        )}
      </div>

      <Cart items={cartItems} onRemoveItem={handleRemoveFromCart} />
    </div>
  );
}