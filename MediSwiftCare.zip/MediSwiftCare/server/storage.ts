import { InsertUser, User, Medicine, Doctor, Ambulance, Order, Appointment } from "@shared/schema";
import session from "express-session";
import createMemoryStore from "memorystore";

const MemoryStore = createMemoryStore(session);

export interface IStorage {
  sessionStore: session.SessionStore;
  
  // User methods
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  // Medicine methods
  getMedicines(): Promise<Medicine[]>;
  getMedicine(id: number): Promise<Medicine | undefined>;
  
  // Doctor methods
  getDoctors(): Promise<Doctor[]>;
  getDoctorsBySpecialization(specialization: string): Promise<Doctor[]>;
  getDoctor(id: number): Promise<Doctor | undefined>;
  
  // Ambulance methods
  getAvailableAmbulances(): Promise<Ambulance[]>;
  updateAmbulanceLocation(id: number, location: string): Promise<Ambulance>;
  
  // Order methods
  createOrder(order: Omit<Order, "id">): Promise<Order>;
  getOrdersByUser(userId: number): Promise<Order[]>;
  updateOrderStatus(id: number, status: string): Promise<Order>;
  
  // Appointment methods
  createAppointment(appointment: Omit<Appointment, "id">): Promise<Appointment>;
  getAppointmentsByUser(userId: number): Promise<Appointment[]>;
  updateAppointmentStatus(id: number, status: string): Promise<Appointment>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private medicines: Map<number, Medicine>;
  private doctors: Map<number, Doctor>;
  private ambulances: Map<number, Ambulance>;
  private orders: Map<number, Order>;
  private appointments: Map<number, Appointment>;
  sessionStore: session.SessionStore;
  currentId: number;

  constructor() {
    this.users = new Map();
    this.medicines = new Map();
    this.doctors = new Map();
    this.ambulances = new Map();
    this.orders = new Map();
    this.appointments = new Map();
    this.currentId = 1;
    this.sessionStore = new MemoryStore({
      checkPeriod: 86400000,
    });
    
    // Initialize with mock data
    this.initializeMockData();
  }

  private initializeMockData() {
    // Add mock medicines
    const medicines = [
      {
        id: 1,
        name: "Paracetamol 500 mg",
        description: "Common pain reliever and fever reducer. Used for headaches, muscle aches, and fever.",
        price: 3.03,
        inStock: true,
        image: "https://placehold.co/400x300"
      },
      {
        id: 2,
        name: "Ciprofloxacin 250 mg",
        description: "Antibiotic used to treat various bacterial infections.",
        price: 8.00,
        inStock: true,
        image: "https://placehold.co/400x300"
      },
      {
        id: 3,
        name: "Amoxicillin 500 mg",
        description: "Penicillin antibiotic that fights bacteria. Used for various bacterial infections.",
        price: 25.00,
        inStock: true,
        image: "https://placehold.co/400x300"
      },
      {
        id: 4,
        name: "Omeprazole 20 mg",
        description: "Reduces stomach acid production. Used for heartburn and acid reflux.",
        price: 15.00,
        inStock: true,
        image: "https://placehold.co/400x300"
      },
      {
        id: 5,
        name: "Metformin 500 mg",
        description: "Oral diabetes medicine that helps control blood sugar levels.",
        price: 12.00,
        inStock: true,
        image: "https://placehold.co/400x300"
      },
      {
        id: 6,
        name: "Amlodipine 5 mg",
        description: "Calcium channel blocker used to treat high blood pressure and angina.",
        price: 8.00,
        inStock: true,
        image: "https://placehold.co/400x300"
      },
      {
        id: 7,
        name: "Azithromycin 500 mg",
        description: "Antibiotic used to treat various bacterial infections including respiratory infections.",
        price: 60.00,
        inStock: true,
        image: "https://placehold.co/400x300"
      },
      {
        id: 8,
        name: "Cetirizine 10 mg",
        description: "Antihistamine that reduces symptoms of allergies and hay fever.",
        price: 2.75,
        inStock: true,
        image: "https://placehold.co/400x300"
      },
      {
        id: 9,
        name: "Ibuprofen 400 mg",
        description: "Anti-inflammatory drug used for pain relief and reducing fever.",
        price: 10.00,
        inStock: true,
        image: "https://placehold.co/400x300"
      },
      {
        id: 10,
        name: "Pantoprazole 40 mg",
        description: "Proton pump inhibitor that reduces stomach acid production.",
        price: 25.00,
        inStock: true,
        image: "https://placehold.co/400x300"
      },
      {
        id: 11,
        name: "Montelukast 10 mg",
        description: "Used to prevent asthma attacks and manage seasonal allergies.",
        price: 50.00,
        inStock: true,
        image: "https://placehold.co/400x300"
      },
      {
        id: 12,
        name: "Salbutamol Inhaler",
        description: "Bronchodilator that relaxes muscles in the airways and increases air flow to the lungs.",
        price: 100.00,
        inStock: true,
        image: "https://placehold.co/400x300"
      }
    ];

    medicines.forEach(medicine => {
      this.medicines.set(medicine.id, medicine);
    });

    // Add mock doctors
    this.doctors.set(1, {
      id: 1,
      name: "Dr. John Smith",
      specialization: "Cardiologist",
      rating: 4.8,
      availableSlots: 5,
      image: "https://placehold.co/400x400"
    });

    // Add mock ambulances
    this.ambulances.set(1, {
      id: 1,
      vehicleNumber: "AMB-001",
      status: "available",
      currentLocation: "Downtown Medical Center"
    });
  }

  // User methods
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.currentId++;
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }

  // Medicine methods
  async getMedicines(): Promise<Medicine[]> {
    return Array.from(this.medicines.values());
  }

  async getMedicine(id: number): Promise<Medicine | undefined> {
    return this.medicines.get(id);
  }

  // Doctor methods
  async getDoctors(): Promise<Doctor[]> {
    return Array.from(this.doctors.values());
  }

  async getDoctorsBySpecialization(specialization: string): Promise<Doctor[]> {
    return Array.from(this.doctors.values()).filter(
      (doctor) => doctor.specialization.toLowerCase() === specialization.toLowerCase()
    );
  }

  async getDoctor(id: number): Promise<Doctor | undefined> {
    return this.doctors.get(id);
  }

  // Ambulance methods
  async getAvailableAmbulances(): Promise<Ambulance[]> {
    return Array.from(this.ambulances.values()).filter(
      (ambulance) => ambulance.status === "available"
    );
  }

  async updateAmbulanceLocation(id: number, location: string): Promise<Ambulance> {
    const ambulance = this.ambulances.get(id);
    if (!ambulance) throw new Error("Ambulance not found");
    
    const updated = { ...ambulance, currentLocation: location };
    this.ambulances.set(id, updated);
    return updated;
  }

  // Order methods
  async createOrder(order: Omit<Order, "id">): Promise<Order> {
    const id = this.currentId++;
    const newOrder: Order = { ...order, id };
    this.orders.set(id, newOrder);
    return newOrder;
  }

  async getOrdersByUser(userId: number): Promise<Order[]> {
    return Array.from(this.orders.values()).filter(
      (order) => order.userId === userId
    );
  }

  async updateOrderStatus(id: number, status: string): Promise<Order> {
    const order = this.orders.get(id);
    if (!order) throw new Error("Order not found");
    
    const updated = { ...order, status };
    this.orders.set(id, updated);
    return updated;
  }

  // Appointment methods
  async createAppointment(appointment: Omit<Appointment, "id">): Promise<Appointment> {
    const id = this.currentId++;
    const newAppointment: Appointment = { ...appointment, id };
    this.appointments.set(id, newAppointment);
    return newAppointment;
  }

  async getAppointmentsByUser(userId: number): Promise<Appointment[]> {
    return Array.from(this.appointments.values()).filter(
      (appointment) => appointment.userId === userId
    );
  }

  async updateAppointmentStatus(id: number, status: string): Promise<Appointment> {
    const appointment = this.appointments.get(id);
    if (!appointment) throw new Error("Appointment not found");
    
    const updated = { ...appointment, status };
    this.appointments.set(id, updated);
    return updated;
  }
}

export const storage = new MemStorage();