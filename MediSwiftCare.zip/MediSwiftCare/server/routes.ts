import type { Express } from "express";
import { createServer, type Server } from "http";
import { WebSocketServer } from 'ws';
import { storage } from "./storage";
import { setupAuth } from "./auth";
import { setupWebSocket } from "./websocket";

export async function registerRoutes(app: Express): Promise<Server> {
  setupAuth(app);

  // Medicine routes
  app.get("/api/medicines", async (_req, res) => {
    const medicines = await storage.getMedicines();
    res.json(medicines);
  });

  app.get("/api/medicines/:id", async (req, res) => {
    const medicine = await storage.getMedicine(parseInt(req.params.id));
    if (!medicine) return res.status(404).send("Medicine not found");
    res.json(medicine);
  });

  // Doctor routes
  app.get("/api/doctors", async (req, res) => {
    const { specialization } = req.query;
    const doctors = specialization
      ? await storage.getDoctorsBySpecialization(specialization as string)
      : await storage.getDoctors();
    res.json(doctors);
  });

  app.get("/api/doctors/:id", async (req, res) => {
    const doctor = await storage.getDoctor(parseInt(req.params.id));
    if (!doctor) return res.status(404).send("Doctor not found");
    res.json(doctor);
  });

  // Ambulance routes
  app.get("/api/ambulances/available", async (_req, res) => {
    const ambulances = await storage.getAvailableAmbulances();
    res.json(ambulances);
  });

  // Order routes
  app.post("/api/orders", async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);

    const order = await storage.createOrder({
      ...req.body,
      userId: req.user!.id,
      status: "pending",
      createdAt: new Date(),
    });
    res.status(201).json(order);
  });

  app.get("/api/orders", async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);

    const orders = await storage.getOrdersByUser(req.user!.id);
    res.json(orders);
  });

  // Appointment routes
  app.post("/api/appointments", async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);

    const appointment = await storage.createAppointment({
      ...req.body,
      userId: req.user!.id,
      status: "scheduled",
    });
    res.status(201).json(appointment);
  });

  app.get("/api/appointments", async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);

    const appointments = await storage.getAppointmentsByUser(req.user!.id);
    res.json(appointments);
  });

  const httpServer = createServer(app);

  // Setup WebSocket server
  const wss = new WebSocketServer({ server: httpServer, path: '/ws' });
  setupWebSocket(wss);

  return httpServer;
}