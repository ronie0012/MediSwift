import { WebSocket, WebSocketServer } from 'ws';
import { Order } from '@shared/schema';

interface DeliveryUpdate {
  orderId: number;
  status: string;
  location: string;
  estimatedTime: string;
}

// Track connected clients by orderId
const clients = new Map<number, Set<WebSocket>>();

// Simulate delivery stages
const deliveryStages = [
  {
    status: "Order Confirmed",
    location: "MediSwift Pharmacy",
    timeOffset: 0
  },
  {
    status: "Order Packed",
    location: "MediSwift Pharmacy",
    timeOffset: 1
  },
  {
    status: "Out for Delivery",
    location: "Delivery Partner en route",
    timeOffset: 2
  },
  {
    status: "Nearby Your Location",
    location: "Within 1km radius",
    timeOffset: 7
  },
  {
    status: "Delivered",
    location: "Delivery Address",
    timeOffset: 10
  }
];

function getEstimatedTime(timeOffset: number): string {
  const now = new Date();
  const estimated = new Date(now.getTime() + timeOffset * 60000); // timeOffset in minutes
  return estimated.toLocaleTimeString();
}

export function setupWebSocket(wss: WebSocketServer) {
  wss.on('connection', (ws: WebSocket) => {
    console.log('New client connected');
    let trackingOrderId: number;

    ws.on('message', (message: string) => {
      try {
        const data = JSON.parse(message);
        if (data.type === 'track_order') {
          trackingOrderId = data.orderId;
          // Add this client to the tracking list for this order
          if (!clients.has(trackingOrderId)) {
            clients.set(trackingOrderId, new Set());
          }
          clients.get(trackingOrderId)?.add(ws);

          // Start sending delivery updates
          let stageIndex = 0;
          const updateInterval = setInterval(() => {
            if (stageIndex < deliveryStages.length) {
              const stage = deliveryStages[stageIndex];
              const update: DeliveryUpdate = {
                orderId: trackingOrderId,
                status: stage.status,
                location: stage.location,
                estimatedTime: getEstimatedTime(stage.timeOffset)
              };
              broadcastDeliveryUpdate(update);
              stageIndex++;
            } else {
              clearInterval(updateInterval);
            }
          }, 10000); // Update every 10 seconds for demo purposes

          // Clean up interval when client disconnects
          ws.on('close', () => {
            clearInterval(updateInterval);
          });
        }
      } catch (error) {
        console.error('Failed to parse message:', error);
      }
    });

    ws.on('close', () => {
      if (trackingOrderId && clients.has(trackingOrderId)) {
        clients.get(trackingOrderId)?.delete(ws);
        if (clients.get(trackingOrderId)?.size === 0) {
          clients.delete(trackingOrderId);
        }
      }
    });
  });
}

export function broadcastDeliveryUpdate(update: DeliveryUpdate) {
  const subscribedClients = clients.get(update.orderId);
  if (subscribedClients) {
    subscribedClients.forEach(client => {
      if (client.readyState === WebSocket.OPEN) {
        client.send(JSON.stringify(update));
      }
    });
  }
}