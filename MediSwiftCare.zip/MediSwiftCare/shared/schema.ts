import { pgTable, text, serial, integer, boolean, timestamp, doublePrecision } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  fullName: text("full_name").notNull(),
  email: text("email").notNull(),
  phoneNumber: text("phone_number").notNull(),
});

export const medicines = pgTable("medicines", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  description: text("description").notNull(),
  price: doublePrecision("price").notNull(),
  inStock: boolean("in_stock").notNull().default(true),
  image: text("image").notNull(),
});

export const doctors = pgTable("doctors", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  specialization: text("specialization").notNull(),
  rating: doublePrecision("rating").notNull(),
  availableSlots: integer("available_slots").notNull(),
  image: text("image").notNull(),
});

export const ambulances = pgTable("ambulances", {
  id: serial("id").primaryKey(),
  vehicleNumber: text("vehicle_number").notNull(),
  status: text("status").notNull(), // 'available', 'busy'
  currentLocation: text("current_location").notNull(),
});

export const orders = pgTable("orders", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  status: text("status").notNull(), // 'pending', 'delivered', 'cancelled'
  totalAmount: doublePrecision("total_amount").notNull(),
  discountedAmount: doublePrecision("discounted_amount").notNull(),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const appointments = pgTable("appointments", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  doctorId: integer("doctor_id").notNull(),
  appointmentTime: timestamp("appointment_time").notNull(),
  status: text("status").notNull(), // 'scheduled', 'completed', 'cancelled'
});

// Insert Schemas
export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
  fullName: true,
  email: true,
  phoneNumber: true,
});

export const insertMedicineSchema = createInsertSchema(medicines);
export const insertDoctorSchema = createInsertSchema(doctors);
export const insertAmbulanceSchema = createInsertSchema(ambulances);
export const insertOrderSchema = createInsertSchema(orders);
export const insertAppointmentSchema = createInsertSchema(appointments);

// Types
export type InsertUser = z.infer<typeof insertUserSchema>;
export type InsertMedicine = z.infer<typeof insertMedicineSchema>;
export type InsertDoctor = z.infer<typeof insertDoctorSchema>;
export type InsertAmbulance = z.infer<typeof insertAmbulanceSchema>;
export type InsertOrder = z.infer<typeof insertOrderSchema>;
export type InsertAppointment = z.infer<typeof insertAppointmentSchema>;

export type User = typeof users.$inferSelect;
export type Medicine = typeof medicines.$inferSelect;
export type Doctor = typeof doctors.$inferSelect;
export type Ambulance = typeof ambulances.$inferSelect;
export type Order = typeof orders.$inferSelect;
export type Appointment = typeof appointments.$inferSelect;
